import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class GUI {

	private JFrame frame;
	JTextArea textArea = new JTextArea();

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
		try {
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 858, 970);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		textArea.setEditable(false);
		
		textArea.setBounds(10, 253, 822, 609);
		frame.getContentPane().add(textArea);
	}
	public void appendTextAreaLine(String text){
		textArea.append(text + "\n");
	}
	public void clearTextArea(){
		textArea.setText(null);
	}
	public void appendTextArea(String text){
		textArea.append(text);
	}

}
