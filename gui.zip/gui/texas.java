/**
 * This class defines a simple driver that continues to play games of No Limits Texas Hold 'Em
 * until the player opts to stop.
 */

import java.util.Scanner;

import javax.swing.JOptionPane;

public class texas {
	public static void main(String[] args) {
		Game newGame = null;
		int response;
		response = JOptionPane.showConfirmDialog(null, "Would you like to play?", "team ETCetera", JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE);
//		Scanner input = new Scanner(System.in);
		while (response == 0) {
			newGame = new Game(); // Create game
			newGame.playGame(); // Play game
			response = JOptionPane.showConfirmDialog(null, "Would you like to play?", "team ETCetera", JOptionPane.YES_OPTION, JOptionPane.QUESTION_MESSAGE);
		}
//		input.close();
	}
	/**
	 * This method prompts the user to play a new game of Texas Hold 'Em Poker
	 * and returns a boolean indicating whether or not the user wants to play
	 * a game.
	 * @param input		A Scanner through which to read user input
	 * @return			True if the user wants to play a game, false
	 * 					if the user indicated otherwise.
	 */
	public static boolean userWantsToPlay(Scanner input) {
		String userInput = "";
		while (true) {
			System.out.print("Welcome! Do you want to play a game of No Limits Texas Hold 'Em (y/n)? ");
			userInput = input.next();
			char userChoice = userInput.toLowerCase().charAt(0);
			if (userChoice == 'y') {
				return true;
			} else if (userChoice == 'n') {
				return false;
			} else {
				System.out.println("Invalid input!");
			}
		}
	}
}
