import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;


public class HoldEmGui extends JFrame {

	private JPanel contentPane;
	private Game newGame;
	private JButton btnLetsPlay;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HoldEmGui frame = new HoldEmGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public HoldEmGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setIcon(new ImageIcon("..\\HoldEmGui\\images\\ETC.png"));
		lblNewLabel.setBounds(36, 25, 143, 113);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Version 3.0");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setBounds(53, 149, 322, 37);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Texas Hold 'em Poker!");
		lblNewLabel_2.setFont(new Font("Impact", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(221, 50, 211, 74);
		contentPane.add(lblNewLabel_2);
		
		btnLetsPlay = new JButton("Let's Play!");
		btnLetsPlay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLetsPlay.setText("Let's Play again!");
				try{
				GameGui frame2 = new GameGui(); // Create game
				frame2.setVisible(true);
				frame2.playGame(); // Play game
				} catch (Exception f){
			
			}

			}
		});
		btnLetsPlay.setBounds(89, 192, 200, 50);
		contentPane.add(btnLetsPlay);
	}
}
